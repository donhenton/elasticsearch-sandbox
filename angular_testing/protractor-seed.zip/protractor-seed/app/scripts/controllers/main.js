'use strict';

/**
 * @ngdoc function
 * @name chaptersixApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the chaptersixApp
 */
angular.module('chaptersixApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
